/*!
 * Copyright (c) 2016-2017 Digital Bazaar, Inc. All rights reserved.
 */
var config = require('bedrock').config;

var permissions = config.permission.permissions;
